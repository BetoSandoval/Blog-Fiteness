$(document).ready(function(){


$('.menu-icon').on('click', function(){
  $('nav').slideToggle();
})


})
